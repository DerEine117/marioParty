package net.rknabe.marioparty.game1;

public enum FieldState {
    EMPTY,
    A,
    B
}
